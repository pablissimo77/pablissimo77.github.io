$(document).ready(function () {
  if (themeConfig.fancybox.enable) {
    Theme.fancybox.register();
  }
  Theme.backToTop.register();
});
