# hexo-theme-mints

> A super cool theme for hexo

## Install

```bash
git clone https://github.com/mintsweet/hexo-theme-mints themes/mints
```

Modify the theme field of the blog configuration file `_config.yml` to `mints`.

```bash
# Extensions
## Plugins: https://hexo.io/plugins/
## Themes: https://hexo.io/themes/
theme: mints
```

## License

[MIT](./LICENSE)
