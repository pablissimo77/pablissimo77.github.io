module.exports = {
  extends: ["prettier"],
  rules: {},
};
