hljs.highlightAll()
